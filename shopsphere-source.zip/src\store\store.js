
import { configureStore } from '@reduxjs/toolkit'

import cartReducer from './slices/cartSlice'
import wishlistReducer from './slices/wishlistSlice'
import authReducer from './slices/authSlice'
import compareReducer from './slices/compareSlice'

export const store = configureStore({
  reducer: {
    cart: cartReducer,
    wishlist: wishlistReducer,
    auth: authReducer,
    compare: compareReducer,
  },
})
